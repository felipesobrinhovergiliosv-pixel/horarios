# Quadro — grade horária escolar

Organizador de grade horária: cadastro de escola, turmas, disciplinas e professores
(com disponibilidade e preferências), um solver que monta a grade **sem nenhum tempo
vago e sem nenhum conflito**, e o Claude como apoio inteligente (importar cadastro de
um texto solto, sugerir carga horária, distribuir professores, diagnosticar travas e
revisar a qualidade pedagógica da grade pronta).

## Como o projeto está organizado

```
quadro-grade-horaria/
├── frontend/     ← HTML + CSS + JS puro (sem framework, sem build)
└── backend/      ← API Java (Spring Boot / Maven) que fala com o Claude
```

- **O solver que monta a grade roda no navegador** (`frontend/js/core.js`). É
  determinístico — usa emparelhamento bipartido (algoritmo de Kuhn) tempo a tempo —
  e não precisa de rede, então não depende do backend.
- **O backend Java existe para guardar sua chave da API da Anthropic com segurança.**
  Um app 100% estático não pode chamar a API do Claude diretamente do navegador sem
  expor a chave a qualquer pessoa que abra o DevTools. O Java resolve isso: guarda a
  chave como variável de ambiente no servidor e repassa as chamadas.
- Uma cópia do `frontend/` já vem dentro de `backend/src/main/resources/static/`,
  para que rodar só o backend já sirva o app inteiro em `http://localhost:8080`.

## Como rodar (mais simples — um comando só)

Pré-requisitos: **Java 17+** e **Maven 3.6+** instalados.

```bash
cd backend

# Linux/Mac
export ANTHROPIC_API_KEY=sk-ant-sua-chave-aqui

# Windows (PowerShell)
$env:ANTHROPIC_API_KEY="sk-ant-sua-chave-aqui"

mvn spring-boot:run
```

Abra **http://localhost:8080** no navegador. Pronto — cadastro, solver e chamadas ao
Claude tudo funcionando no mesmo endereço.

Sem a variável de ambiente configurada, o app funciona normalmente (cadastro e o
solver não dependem do Claude), mas os botões que usam IA (“Importar de um texto”,
“Sugerir carga horária”, “Distribuir professores”, “O que travou?”, “Revisão
pedagógica”) mostram um aviso explicando que a chave não está configurada. O selo
no topo da tela também indica isso.

## Como rodar frontend e backend separados

Se preferir servir o `frontend/` com outra ferramenta (Live Server, `npx serve`,
nginx, etc.) enquanto o backend roda em outra porta:

1. Rode o backend normalmente (`mvn spring-boot:run`, porta 8080 por padrão).
2. Em `frontend/index.html`, ajuste a tag:
   ```html
   <meta name="api-base" content="http://localhost:8080">
   ```
3. Sirva `frontend/` com a ferramenta de sua preferência.

O `ClaudeController.java` já libera CORS de qualquer origem (`@CrossOrigin("*")`)
para facilitar esse cenário em desenvolvimento — restrinja isso antes de publicar
em produção.

## Gerar um .jar para produção

```bash
cd backend
mvn clean package
java -jar target/quadro-api.jar
```

## Endpoints da API

| Método | Rota                  | Descrição                                           |
|--------|------------------------|------------------------------------------------------|
| GET    | `/api/claude/status`   | Diz se a chave está configurada e qual modelo está em uso |
| POST   | `/api/claude/mensagem` | Recebe `{prompt, system, maxTokens}`, repassa ao Claude e devolve `{texto}` |

## Configuração

Tudo em `backend/src/main/resources/application.properties`:

```properties
server.port=${PORT:8080}
anthropic.api-key=${ANTHROPIC_API_KEY:}
anthropic.model=${ANTHROPIC_MODEL:claude-sonnet-4-6}
```

## O que já vem cadastrado de exemplo

Ao abrir pela primeira vez (sem nada salvo no navegador), o app já carrega uma
escola de teste — **E.M. Cecília Meireles** — com 4 turmas, 8 disciplinas, 8
professores (com matrícula, disciplinas, disponibilidade e preferências de turma
variadas) e a grade curricular inteira preenchida. Vá direto na aba **Quadro** e
toque em "Gerar grade horária" para ver o solver em ação. O botão **Exemplo** no
topo recarrega esses dados a qualquer momento; **Limpar** apaga tudo.

Cada navegador guarda seu próprio cadastro em `localStorage` — não há banco de
dados nesta versão.
