package com.escola.quadro.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import java.util.Map;

/**
 * Fala com a API da Anthropic (POST /v1/messages) em nome do frontend.
 * A chave fica so aqui no servidor (variavel de ambiente ANTHROPIC_API_KEY),
 * nunca chega ao navegador do usuario.
 */
@Service
public class ClaudeService {

    private static final String URL_ANTHROPIC = "https://api.anthropic.com/v1/messages";
    private static final String VERSAO_API = "2023-06-01";

    @Value("${anthropic.api-key:}")
    private String apiKey;

    @Value("${anthropic.model:claude-sonnet-4-6}")
    private String modelo;

    private final HttpClient http = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(15))
            .build();

    private final ObjectMapper mapper = new ObjectMapper();

    public boolean chaveConfigurada() {
        return apiKey != null && !apiKey.isBlank();
    }

    public String modeloAtual() {
        return modelo;
    }

    /**
     * Envia um prompt ao Claude e devolve apenas o texto da resposta,
     * concatenando os blocos de tipo "text" do retorno da API.
     */
    public String enviar(String prompt, String system, int maxTokens) throws Exception {
        if (!chaveConfigurada()) {
            throw new IllegalStateException(
                    "A variavel de ambiente ANTHROPIC_API_KEY nao esta configurada no servidor.");
        }

        Map<String, Object> mensagem = Map.of("role", "user", "content", prompt == null ? "" : prompt);

        Map<String, Object> corpo = Map.of(
                "model", modelo,
                "max_tokens", Math.max(1, maxTokens),
                "system", system == null ? "" : system,
                "messages", List.of(mensagem)
        );

        String json = mapper.writeValueAsString(corpo);

        HttpRequest requisicao = HttpRequest.newBuilder()
                .uri(URI.create(URL_ANTHROPIC))
                .timeout(Duration.ofSeconds(120))
                .header("Content-Type", "application/json")
                .header("x-api-key", apiKey)
                .header("anthropic-version", VERSAO_API)
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();

        HttpResponse<String> resposta = http.send(requisicao, HttpResponse.BodyHandlers.ofString());

        if (resposta.statusCode() / 100 != 2) {
            throw new RuntimeException(
                    "A chamada a API da Anthropic falhou (HTTP " + resposta.statusCode() + "): " + resumir(resposta.body()));
        }

        JsonNode raiz = mapper.readTree(resposta.body());
        JsonNode blocos = raiz.get("content");
        StringBuilder texto = new StringBuilder();
        if (blocos != null && blocos.isArray()) {
            for (JsonNode bloco : blocos) {
                if ("text".equals(bloco.path("type").asText())) {
                    texto.append(bloco.path("text").asText());
                }
            }
        }
        return texto.toString();
    }

    private String resumir(String corpo) {
        if (corpo == null) return "";
        return corpo.length() > 500 ? corpo.substring(0, 500) + "..." : corpo;
    }
}
