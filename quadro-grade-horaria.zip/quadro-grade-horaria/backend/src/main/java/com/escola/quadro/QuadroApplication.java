package com.escola.quadro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Ponto de entrada da API do Quadro.
 *
 * Esta aplicacao tem dois papeis:
 *   1) Servir o frontend estatico (HTML/CSS/JS) que fica em src/main/resources/static.
 *   2) Expor /api/claude/** como uma ponte segura para a API da Anthropic,
 *      guardando a chave no servidor (o navegador nunca a ve).
 */
@SpringBootApplication
public class QuadroApplication {

    public static void main(String[] args) {
        SpringApplication.run(QuadroApplication.class, args);
    }
}
