package com.escola.quadro.web;

import com.escola.quadro.service.ClaudeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Endpoints usados pelo frontend (js/claude.js).
 *
 * GET  /api/claude/status   -> diz se a chave esta configurada no servidor
 * POST /api/claude/mensagem -> encaminha {prompt, system, maxTokens} ao Claude
 *                               e devolve {texto: "..."}
 */
@RestController
@RequestMapping("/api/claude")
@CrossOrigin(origins = "*") // ajuste para o dominio do frontend em producao
public class ClaudeController {

    private final ClaudeService claudeService;

    public ClaudeController(ClaudeService claudeService) {
        this.claudeService = claudeService;
    }

    @GetMapping("/status")
    public Map<String, Object> status() {
        return Map.of(
                "configurado", claudeService.chaveConfigurada(),
                "modelo", claudeService.modeloAtual()
        );
    }

    @PostMapping("/mensagem")
    public ResponseEntity<Map<String, Object>> mensagem(@RequestBody Map<String, Object> corpo) {
        String prompt = String.valueOf(corpo.getOrDefault("prompt", ""));
        String system = String.valueOf(corpo.getOrDefault("system", ""));
        int maxTokens = 1400;
        Object bruto = corpo.get("maxTokens");
        if (bruto instanceof Number numero) {
            maxTokens = numero.intValue();
        }

        try {
            String texto = claudeService.enviar(prompt, system, maxTokens);
            return ResponseEntity.ok(Map.of("texto", texto));
        } catch (IllegalStateException semChave) {
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                    .body(Map.of("erro", semChave.getMessage()));
        } catch (Exception falha) {
            return ResponseEntity.status(HttpStatus.BAD_GATEWAY)
                    .body(Map.of("erro", falha.getMessage() == null ? "Falha ao falar com o Claude." : falha.getMessage()));
        }
    }
}
