import { ESTADO_VAZIO, exemplo, gerarSlots, validar, resolver, conferir, construirHorarios } from './core.js';
import { salvarEstado, carregarEstado } from './storage.js';
import { montarInterface } from './ui.js';

let ESTADO = null;
let UI = { etapa: 0, ocupado: '', aviso: null, resposta: '', confirmando: false };
let temporizadorSalvar = null;

function persistir() {
  clearTimeout(temporizadorSalvar);
  temporizadorSalvar = setTimeout(() => salvarEstado(ESTADO), 500);
}

function atualizarEstado(patch, semRender) {
  ESTADO = { ...ESTADO, ...patch };
  persistir();
  if (!semRender) renderizar();
}

function atualizarUI(patch) {
  UI = { ...UI, ...patch };
  renderizar();
}

async function comIA(rotulo, fn) {
  atualizarUI({ ocupado: rotulo, aviso: null, resposta: '' });
  try {
    await fn();
  } catch (err) {
    atualizarUI({ ocupado: '', aviso: String((err && err.message) || err) });
    return;
  }
  atualizarUI({ ocupado: '' });
}

function gerar() {
  atualizarUI({ ocupado: 'Montando', resposta: '', aviso: null });
  setTimeout(() => {
    try {
      const r = resolver(ESTADO);
      if (!r.ok) {
        atualizarEstado({ resultado: null }, true);
        atualizarUI({ ocupado: '', aviso: r.motivo });
        return;
      }
      const falhas = conferir(r, ESTADO);
      atualizarEstado({ resultado: r }, true);
      atualizarUI({ ocupado: '', aviso: falhas.length ? ('Conferência falhou: ' + falhas.join(' ')) : null });
    } catch (err) {
      atualizarUI({ ocupado: '', aviso: 'Erro ao montar: ' + String((err && err.message) || err) });
    }
  }, 30);
}

function ctxTexto() {
  const slots = gerarSlots(ESTADO.dias, ESTADO.horarios);
  const D = Object.fromEntries(ESTADO.disciplinas.map((d) => [d.id, d.nome]));
  const T = Object.fromEntries(ESTADO.turmas.map((t) => [t.id, t.nome]));
  return [
    `Escola: ${ESTADO.escola.nome || 'sem nome'} | Turno ${ESTADO.escola.turno} | Ano ${ESTADO.escola.ano}`,
    `Dias: ${ESTADO.dias.join(', ')} | ${ESTADO.escola.aulasPorDia} aulas de ${ESTADO.escola.duracao} min | ${slots.length} tempos na semana`,
    'REGRA: nenhuma turma pode ter tempo vago; cada turma soma exatamente ' + slots.length + ' aulas por semana.',
    `Turmas: ${ESTADO.turmas.map((t) => t.nome).join(', ') || '—'}`,
    `Disciplinas: ${ESTADO.disciplinas.map((d) => d.nome).join(', ') || '—'}`,
    'Professores:',
    ...ESTADO.professores.map((p) => `- ${p.matricula} ${p.nome} | leciona: ${p.disciplinas.map((x) => D[x]).join(', ') || '—'} | livre em ${slots.filter((s) => p.disp[s.id] !== false).length}/${slots.length} tempos | prefere: ${(p.prefTurmas || []).map((x) => T[x]).join(', ') || '—'}`),
    'Grade curricular (turma / disciplina / aulas por semana / matrícula):',
    ...Object.entries(ESTADO.grade).filter(([, c]) => c && Number(c.carga)).map(([k, c]) => { const [t, d] = k.split('|'); return `- ${T[t]} / ${D[d]} / ${c.carga} / ${c.prof || 'sem professor'}`; }),
  ].join('\n');
}

const acoes = {
  atualizarEstado,
  atualizarUI,
  comIA,
  gerar,
  ctxTexto,
  setEscola(patch) {
    const escola = { ...ESTADO.escola, ...patch };
    atualizarEstado({ escola, horarios: construirHorarios(escola), resultado: null });
  },
  reiniciarExemplo() {
    ESTADO = exemplo();
    UI = { ...UI, confirmando: false, aviso: null, resposta: '' };
    persistir();
    renderizar();
  },
  limparTudo() {
    ESTADO = { ...ESTADO_VAZIO };
    UI = { ...UI, etapa: 0, confirmando: false, aviso: null, resposta: '' };
    persistir();
    renderizar();
  },
};

function renderizar() {
  const slots = gerarSlots(ESTADO.dias, ESTADO.horarios);
  const val = validar(ESTADO);
  montarInterface({ estado: ESTADO, ui: UI, slots, val, acoes });
}

function iniciar() {
  const salvo = carregarEstado();
  ESTADO = (salvo && salvo.turmas && salvo.escola) ? { ...ESTADO_VAZIO, ...salvo } : exemplo();
  renderizar();
}

iniciar();
