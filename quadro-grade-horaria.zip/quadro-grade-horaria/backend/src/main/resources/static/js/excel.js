import { gerarSlots } from './core.js';

function nomeAba(s, usados) {
  let n = String(s).replace(/[[\]:*?/\\]/g, '').slice(0, 28) || 'Aba';
  let f = n, i = 2;
  while (usados.has(f)) f = n.slice(0, 25) + ' ' + i++;
  usados.add(f);
  return f;
}

export function exportarExcel(e) {
  if (typeof XLSX === 'undefined') {
    alert('A biblioteca de exportação (SheetJS) não carregou. Verifique sua conexão com a internet e recarregue a página.');
    return;
  }

  const res = e.resultado, wb = XLSX.utils.book_new(), usados = new Set();
  const T = Object.fromEntries(e.turmas.map((t) => [t.id, t.nome]));
  const D = Object.fromEntries(e.disciplinas.map((d) => [d.id, d.nome]));
  const P = Object.fromEntries(e.professores.map((p) => [p.matricula, p.nome]));
  const cel = {};
  if (res) res.aulas.forEach((a) => { cel[`${a.turma}|${res.atrib[a.id]}`] = { d: D[a.disc], p: P[a.prof], m: a.prof }; });
  const cab = `${e.escola.nome || 'Grade horária'} — ${e.escola.turno} ${e.escola.ano}`;

  const linhas = (fn) => e.horarios.map((h, ai) => {
    const rot = `${h.inicio} – ${h.fim}`;
    if (h.intervalo) return [rot, ...e.dias.map(() => (h.rotulo || 'INTERVALO').toUpperCase())];
    return [rot, ...e.dias.map((_, di) => fn(di, ai))];
  });

  const geral = [[cab.toUpperCase()], [], ['QUADRO GERAL']];
  e.dias.forEach((dia, di) => {
    geral.push([], [dia.toUpperCase(), ...e.turmas.map((t) => t.nome)]);
    e.horarios.forEach((h, ai) => {
      const rot = `${h.inicio} – ${h.fim}`;
      if (h.intervalo) { geral.push([rot, ...e.turmas.map(() => (h.rotulo || 'INTERVALO').toUpperCase())]); return; }
      geral.push([rot, ...e.turmas.map((t) => { const c = cel[`${t.id}|${di}-${ai}`]; return c ? `${c.d} — ${c.p}` : '—'; })]);
    });
  });
  const wsG = XLSX.utils.aoa_to_sheet(geral);
  wsG['!cols'] = [{ wch: 15 }, ...e.turmas.map(() => ({ wch: 30 }))];
  XLSX.utils.book_append_sheet(wb, wsG, nomeAba('Quadro geral', usados));

  e.turmas.forEach((t) => {
    const aoa = [[`TURMA ${t.nome}`], [cab], [], ['Horário', ...e.dias]];
    linhas((di, ai) => { const c = cel[`${t.id}|${di}-${ai}`]; return c ? `${c.d} — ${c.p}` : '—'; }).forEach((r) => aoa.push(r));
    const cg = e.disciplinas.map((d) => { const g = e.grade[`${t.id}|${d.id}`]; return g && Number(g.carga) ? [d.nome, Number(g.carga), P[g.prof] || '—'] : null; }).filter(Boolean);
    aoa.push([], ['Carga semanal', 'Aulas', 'Professor'], ...cg);
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws['!cols'] = [{ wch: 18 }, ...e.dias.map(() => ({ wch: 28 }))];
    XLSX.utils.book_append_sheet(wb, ws, nomeAba(t.nome, usados));
  });

  const pr = [['HORÁRIO POR PROFESSOR'], [cab]];
  e.professores.forEach((p) => {
    pr.push([], [`${p.matricula} — ${p.nome}`], ['Horário', ...e.dias]);
    linhas((di, ai) => {
      const a = e.turmas.map((t) => { const c = cel[`${t.id}|${di}-${ai}`]; return c && c.m === p.matricula ? `${c.d} — ${t.nome}` : null; }).filter(Boolean);
      return a[0] || (p.disp[`${di}-${ai}`] === false ? 'indisponível' : 'livre');
    }).forEach((r) => pr.push(r));
  });
  const wsP = XLSX.utils.aoa_to_sheet(pr);
  wsP['!cols'] = [{ wch: 18 }, ...e.dias.map(() => ({ wch: 28 }))];
  XLSX.utils.book_append_sheet(wb, wsP, nomeAba('Por professor', usados));

  const slots = gerarSlots(e.dias, e.horarios);
  const cd = [['Matrícula', 'Nome', 'Disciplinas', 'Aulas na semana', 'Tempos disponíveis', 'Turmas preferidas']];
  e.professores.forEach((p) => cd.push([p.matricula, p.nome, p.disciplinas.map((x) => D[x]).join(', '),
    res ? res.aulas.filter((a) => a.prof === p.matricula).length : 0,
    slots.filter((s) => p.disp[s.id] !== false).length, (p.prefTurmas || []).map((x) => T[x]).join(', ')]));
  const wsC = XLSX.utils.aoa_to_sheet(cd);
  wsC['!cols'] = [{ wch: 12 }, { wch: 26 }, { wch: 32 }, { wch: 16 }, { wch: 18 }, { wch: 24 }];
  XLSX.utils.book_append_sheet(wb, wsC, nomeAba('Cadastro', usados));

  const out = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const url = URL.createObjectURL(new Blob([out], { type: 'application/octet-stream' }));
  const a = document.createElement('a');
  a.href = url;
  a.download = `${(e.escola.nome || 'grade-horaria').toLowerCase().replace(/\s+/g, '-')}-${e.escola.ano}.xlsx`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}
