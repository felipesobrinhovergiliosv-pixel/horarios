import {
  DIAS_BASE, TURNOS, uid, gerarSlots, somaTurma, fecharCargaEmT, extrairJSON, esc,
} from './core.js';
import { chamarClaude } from './claude.js';
import { exportarExcel } from './excel.js';

/* ---------------- estado de UI puramente visual (não persistido) ---------------- */

let profAberto = null;
let mostrarImportacao = false;
let rascunhoImportacao = '';
let vistaQuadro = 'turma';
let alvoQuadro = null;
let pararPintura = null; // referência ao listener global de pointerup ativo na disponibilidade

const ETAPAS = [
  { id: 0, t: 'Escola', ic: 'building-2', sub: 'Turno, aulas e intervalos' },
  { id: 1, t: 'Turmas', ic: 'layout-grid', sub: 'Turmas e disciplinas' },
  { id: 2, t: 'Professores', ic: 'users', sub: 'Cadastro e disponibilidade' },
  { id: 3, t: 'Currículo', ic: 'book-open', sub: 'Aulas por semana' },
  { id: 4, t: 'Quadro', ic: 'school', sub: 'Gerar e exportar' },
];

const icones = () => { if (window.lucide) window.lucide.createIcons(); };

/* ---------------- ponto de entrada ---------------- */

export function montarInterface({ estado, ui, slots, val, acoes }) {
  renderTopo(estado, slots, acoes);
  renderConfirma(ui, acoes);
  renderTrilho(ui, acoes);
  renderAlerta(ui, val, acoes);
  renderPalco(estado, ui, slots, val, acoes);
  renderResposta(ui, acoes);
  renderAvisos(val);
  icones();
}

/* ---------------- topo ---------------- */

function renderTopo(estado, slots, acoes) {
  const el = document.getElementById('topo');
  el.innerHTML = `
    <div class="marca">
      <span class="giz-marca">Quadro</span>
      <span class="sub-marca">${esc(estado.escola.nome || 'escola sem nome')}</span>
    </div>
    <div class="topo-dir">
      <span class="pill">${slots.length} tempos/semana</span>
      <span class="pill" id="pill-api">verificando API…</span>
      <button type="button" class="btn-topo" id="btn-exemplo"><i data-lucide="flask-conical"></i> Exemplo</button>
      <button type="button" class="btn-topo" id="btn-limpar"><i data-lucide="rotate-ccw"></i> Limpar</button>
    </div>`;
  el.querySelector('#btn-exemplo').addEventListener('click', () => acoes.reiniciarExemplo());
  el.querySelector('#btn-limpar').addEventListener('click', () => acoes.atualizarUI({ confirmando: true }));

  if (!window.__quadroApiChecada) {
    window.__quadroApiChecada = true;
    import('./claude.js').then(({ statusApi }) => statusApi()).then((s) => {
      const pill = document.getElementById('pill-api');
      if (!pill) return;
      if (s.offline) { pill.textContent = 'API indisponível'; pill.title = 'Não foi possível contatar o backend Java.'; }
      else if (s.configurado) { pill.textContent = 'Claude conectado'; pill.title = `Modelo: ${s.modelo || ''}`; }
      else { pill.textContent = 'chave não configurada'; pill.title = 'Defina ANTHROPIC_API_KEY no servidor.'; }
    });
  }
}

function renderConfirma(ui, acoes) {
  const el = document.getElementById('confirma-area');
  if (!ui.confirmando) { el.innerHTML = ''; return; }
  el.innerHTML = `
    <div class="confirma">
      <span>Apagar todo o cadastro e começar do zero?</span>
      <button type="button" class="btn-mini perigo" id="btn-apagar-tudo">Apagar tudo</button>
      <button type="button" class="btn-mini" id="btn-cancelar-apagar">Cancelar</button>
    </div>`;
  el.querySelector('#btn-apagar-tudo').addEventListener('click', () => acoes.limparTudo());
  el.querySelector('#btn-cancelar-apagar').addEventListener('click', () => acoes.atualizarUI({ confirmando: false }));
}

function renderTrilho(ui, acoes) {
  const el = document.getElementById('trilho');
  el.innerHTML = ETAPAS.map((s) => `
    <button type="button" class="passo${ui.etapa === s.id ? ' ativo' : ''}" data-etapa="${s.id}">
      <i data-lucide="${s.ic}"></i>
      <span class="passo-t">${s.t}</span>
      <span class="passo-s">${s.sub}</span>
    </button>`).join('');
  el.querySelectorAll('[data-etapa]').forEach((b) => {
    b.addEventListener('click', () => acoes.atualizarUI({ etapa: Number(b.dataset.etapa) }));
  });
}

function renderAlerta(ui, val, acoes) {
  const el = document.getElementById('alerta-area');
  if (!val.erros.length && !ui.aviso) { el.innerHTML = ''; return; }
  const extras = val.erros.slice(0, 4);
  el.innerHTML = `
    <div class="alerta">
      <i data-lucide="alert-triangle"></i>
      <div class="alerta-txt">
        ${ui.aviso ? `<p class="alerta-forte">${esc(ui.aviso)}</p>` : ''}
        ${extras.map((x) => `<p>${esc(x)}</p>`).join('')}
        ${val.erros.length > 4 ? `<p>e mais ${val.erros.length - 4}.</p>` : ''}
      </div>
      ${ui.aviso ? '<button type="button" class="fechar" id="btn-fechar-alerta"><i data-lucide="x"></i></button>' : ''}
    </div>`;
  const fechar = el.querySelector('#btn-fechar-alerta');
  if (fechar) fechar.addEventListener('click', () => acoes.atualizarUI({ aviso: null }));
}

function renderResposta(ui, acoes) {
  const el = document.getElementById('resposta-area');
  if (!ui.resposta) { el.innerHTML = ''; return; }
  el.innerHTML = `
    <div class="resposta-cab"><i data-lucide="sparkles"></i> Claude
      <button type="button" class="fechar" id="btn-fechar-resposta"><i data-lucide="x"></i></button>
    </div>
    <div class="resposta-corpo"></div>`;
  el.querySelector('.resposta-corpo').textContent = ui.resposta;
  el.querySelector('#btn-fechar-resposta').addEventListener('click', () => acoes.atualizarUI({ resposta: '' }));
}

function renderAvisos(val) {
  const el = document.getElementById('avisos-area');
  if (!val.avisos.length) { el.innerHTML = ''; return; }
  el.innerHTML = `
    <details>
      <summary><i data-lucide="chevron-down"></i> ${val.avisos.length} ponto(s) de atenção</summary>
      ${val.avisos.map((x) => `<p>${esc(x)}</p>`).join('')}
    </details>`;
}

/* ---------------- roteador do palco ---------------- */

function renderPalco(estado, ui, slots, val, acoes) {
  const el = document.getElementById('palco');
  if (ui.etapa === 0) return renderEscola(el, estado, acoes);
  if (ui.etapa === 1) return renderTurmas(el, estado, acoes);
  if (ui.etapa === 2) return renderProfessores(el, estado, slots, ui, acoes);
  if (ui.etapa === 3) return renderCurriculo(el, estado, val, ui, acoes);
  if (ui.etapa === 4) return renderQuadro(el, estado, val, ui, acoes);
}

/* ================= ETAPA 0 — Escola ================= */

function renderEscola(el, estado, acoes) {
  const esc_ = estado.escola;
  const slots = gerarSlots(estado.dias, estado.horarios);
  const ultimo = estado.horarios[estado.horarios.length - 1];
  const duracaoTurno = estado.horarios.length ? minutosEntre(esc_.inicio, ultimo.fim) : 0;
  const minIntervalo = (esc_.intervalos || []).reduce((s, i) => s + Number(i.minutos || 0), 0);

  el.innerHTML = `
    <div class="col">
      <section class="bloco">
        <h3>Identificação</h3>
        <p class="nota">Aparece no cabeçalho de todas as abas do Excel.</p>
        <div class="linha-form">
          <label class="campo larga"><span>Nome da escola</span><input id="esc-nome" value="${esc(esc_.nome)}" placeholder="E.M. Cecília Meireles"></label>
          <label class="campo"><span>Ano letivo</span><input id="esc-ano" class="mono" value="${esc(esc_.ano)}"></label>
          <label class="campo"><span>Turno</span>
            <select id="esc-turno">${TURNOS.map((t) => `<option ${t === esc_.turno ? 'selected' : ''}>${t}</option>`).join('')}</select>
          </label>
        </div>
      </section>

      <section class="bloco">
        <h3>Dias letivos</h3>
        <p class="nota">Marque os dias em que há aula.</p>
        <div class="chips" id="chips-dias">
          ${DIAS_BASE.map((d) => `<button type="button" class="chip${estado.dias.includes(d) ? ' on' : ''}" data-dia="${d}">${d}</button>`).join('')}
        </div>
      </section>

      <section class="bloco">
        <h3>Aulas e duração</h3>
        <p class="nota">A régua do dia é recalculada na hora.</p>
        <div class="linha-form">
          <label class="campo"><span>Início do turno</span><input id="esc-inicio" type="time" value="${esc_.inicio}"></label>
          <label class="campo"><span>Duração da aula (min)</span><input id="esc-duracao" type="number" min="15" max="180" value="${esc_.duracao}"></label>
          <label class="campo"><span>Aulas por dia</span><input id="esc-aulas" type="number" min="1" max="14" value="${esc_.aulasPorDia}"></label>
        </div>
      </section>

      <section class="bloco">
        <h3>Intervalos</h3>
        <p class="nota">Recreio, lanche, troca de turno — o solver nunca marca aula nesses espaços.</p>
        <div id="lista-intervalos">
          ${(esc_.intervalos || []).map((iv, i) => `
            <div class="linha-form" data-iv="${i}">
              <label class="campo"><span>Depois da aula nº</span><input type="number" min="1" max="${esc_.aulasPorDia}" value="${iv.depois}" data-iv-campo="depois"></label>
              <label class="campo"><span>Duração (min)</span><input type="number" min="5" value="${iv.minutos}" data-iv-campo="minutos"></label>
              <label class="campo larga"><span>Nome</span><input value="${esc(iv.rotulo)}" data-iv-campo="rotulo"></label>
              <button type="button" class="btn-icone" data-iv-remover="${i}"><i data-lucide="trash-2"></i></button>
            </div>`).join('') || '<p class="vazio">Nenhum intervalo — o turno corre direto.</p>'}
        </div>
        <div class="acoes"><button type="button" class="btn-fantasma" id="btn-add-intervalo"><i data-lucide="plus"></i> Adicionar intervalo</button></div>
      </section>

      <div class="resumo">
        <div class="resumo-cab">Como fica o dia</div>
        <div class="resumo-nums">
          <div><b>${esc_.inicio}</b><span>entrada</span></div>
          <div><b>${ultimo ? ultimo.fim : '—'}</b><span>saída</span></div>
          <div><b>${Math.floor(duracaoTurno / 60)}h${String(duracaoTurno % 60).padStart(2, '0')}</b><span>turno</span></div>
          <div><b>${esc_.aulasPorDia}</b><span>aulas/dia</span></div>
          <div><b>${minIntervalo} min</b><span>intervalo</span></div>
          <div class="destaque"><b>${slots.length}</b><span>tempos/semana</span></div>
        </div>
        <ol class="regua">
          ${estado.horarios.map((h) => `
            <li class="${h.intervalo ? 'iv' : ''}">
              <span class="regua-rot">${esc(h.rotulo)}</span>
              <span class="regua-hora">${h.inicio} – ${h.fim}</span>
            </li>`).join('')}
        </ol>
        <p class="resumo-nota">Cada turma terá exatamente <b>${slots.length} aulas por semana</b> — sem tempo vago. A soma da grade curricular de cada turma precisa bater com esse número.</p>
      </div>
    </div>`;

  // identificação
  el.querySelector('#esc-nome').addEventListener('change', (ev) => acoes.setEscola({ nome: ev.target.value }));
  el.querySelector('#esc-ano').addEventListener('change', (ev) => acoes.setEscola({ ano: ev.target.value }));
  el.querySelector('#esc-turno').addEventListener('change', (ev) => acoes.setEscola({ turno: ev.target.value }));
  enterConfirma(el.querySelector('#esc-nome'));
  enterConfirma(el.querySelector('#esc-ano'));

  // dias
  el.querySelectorAll('[data-dia]').forEach((b) => b.addEventListener('click', () => {
    const d = b.dataset.dia;
    const on = estado.dias.includes(d);
    const novo = on ? estado.dias.filter((x) => x !== d) : DIAS_BASE.filter((x) => estado.dias.includes(x) || x === d);
    acoes.atualizarEstado({ dias: novo, resultado: null });
  }));

  // aulas e duração
  el.querySelector('#esc-inicio').addEventListener('change', (ev) => acoes.setEscola({ inicio: ev.target.value }));
  el.querySelector('#esc-duracao').addEventListener('change', (ev) => acoes.setEscola({ duracao: Math.max(5, Number(ev.target.value) || 0) }));
  el.querySelector('#esc-aulas').addEventListener('change', (ev) => acoes.setEscola({ aulasPorDia: Math.max(1, Number(ev.target.value) || 1) }));

  // intervalos
  el.querySelectorAll('[data-iv]').forEach((linha) => {
    const i = Number(linha.dataset.iv);
    linha.querySelectorAll('[data-iv-campo]').forEach((input) => {
      input.addEventListener('change', () => {
        const campo = input.dataset.ivCampo;
        const valor = campo === 'rotulo' ? input.value : (Number(input.value) || 0);
        const intervalos = esc_.intervalos.map((x, j) => (j === i ? { ...x, [campo]: valor } : x));
        acoes.setEscola({ intervalos });
      });
      enterConfirma(input);
    });
  });
  el.querySelectorAll('[data-iv-remover]').forEach((b) => b.addEventListener('click', () => {
    const i = Number(b.dataset.ivRemover);
    acoes.setEscola({ intervalos: esc_.intervalos.filter((_, j) => j !== i) });
  }));
  el.querySelector('#btn-add-intervalo').addEventListener('click', () => {
    acoes.setEscola({ intervalos: [...(esc_.intervalos || []), { depois: Math.min(esc_.aulasPorDia, 3), minutos: 15, rotulo: 'Intervalo' }] });
  });
}

function minutosEntre(ini, fim) {
  const [h1, m1] = ini.split(':').map(Number);
  const [h2, m2] = fim.split(':').map(Number);
  return (h2 * 60 + m2) - (h1 * 60 + m1);
}

function enterConfirma(input) {
  if (!input) return;
  input.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') { ev.preventDefault(); input.blur(); } });
}

/* ================= ETAPA 1 — Turmas e disciplinas ================= */

function renderTurmas(el, estado, acoes) {
  el.innerHTML = `
    <div class="duas">
      <section class="bloco">
        <h3>Turmas</h3>
        <p class="nota">Cada turma terá aula em todos os tempos, sem janela.</p>
        <div class="linha-add">
          <input id="novo-turma" placeholder="ex.: 6º ano A">
          <button type="button" class="btn" id="btn-add-turma"><i data-lucide="plus"></i> Adicionar</button>
        </div>
        <div class="lista" id="lista-turmas">
          ${estado.turmas.map((t) => `
            <div class="item"><span>${esc(t.nome)}</span>
              <button type="button" class="btn-icone" data-rem-turma="${t.id}"><i data-lucide="trash-2"></i></button></div>`).join('')
            || '<p class="vazio">Cadastre a primeira turma.</p>'}
        </div>
      </section>

      <section class="bloco">
        <h3>Disciplinas</h3>
        <p class="nota">Os cursos que os professores lecionam.</p>
        <div class="linha-add">
          <input id="novo-disc" placeholder="ex.: Matemática">
          <button type="button" class="btn" id="btn-add-disc"><i data-lucide="plus"></i> Adicionar</button>
        </div>
        <div class="lista" id="lista-disc">
          ${estado.disciplinas.map((d) => `
            <div class="item"><span>${esc(d.nome)}</span>
              <button type="button" class="btn-icone" data-rem-disc="${d.id}"><i data-lucide="trash-2"></i></button></div>`).join('')
            || '<p class="vazio">Cadastre as disciplinas oferecidas.</p>'}
        </div>
      </section>
    </div>`;

  const addTurma = () => {
    const input = el.querySelector('#novo-turma');
    const nome = input.value.trim();
    if (!nome) return;
    acoes.atualizarEstado({ turmas: [...estado.turmas, { id: uid(), nome }], resultado: null });
    input.value = '';
  };
  const addDisc = () => {
    const input = el.querySelector('#novo-disc');
    const nome = input.value.trim();
    if (!nome) return;
    acoes.atualizarEstado({ disciplinas: [...estado.disciplinas, { id: uid(), nome }], resultado: null });
    input.value = '';
  };
  el.querySelector('#btn-add-turma').addEventListener('click', addTurma);
  el.querySelector('#btn-add-disc').addEventListener('click', addDisc);
  el.querySelector('#novo-turma').addEventListener('keydown', (ev) => { if (ev.key === 'Enter') { ev.preventDefault(); addTurma(); } });
  el.querySelector('#novo-disc').addEventListener('keydown', (ev) => { if (ev.key === 'Enter') { ev.preventDefault(); addDisc(); } });

  el.querySelectorAll('[data-rem-turma]').forEach((b) => b.addEventListener('click', () => {
    const id = b.dataset.remTurma;
    acoes.atualizarEstado({
      resultado: null,
      turmas: estado.turmas.filter((t) => t.id !== id),
      grade: Object.fromEntries(Object.entries(estado.grade).filter(([k]) => !k.startsWith(id + '|'))),
      professores: estado.professores.map((p) => ({ ...p, prefTurmas: (p.prefTurmas || []).filter((x) => x !== id) })),
    });
  }));
  el.querySelectorAll('[data-rem-disc]').forEach((b) => b.addEventListener('click', () => {
    const id = b.dataset.remDisc;
    acoes.atualizarEstado({
      resultado: null,
      disciplinas: estado.disciplinas.filter((d) => d.id !== id),
      grade: Object.fromEntries(Object.entries(estado.grade).filter(([k]) => !k.endsWith('|' + id))),
      professores: estado.professores.map((p) => ({ ...p, disciplinas: p.disciplinas.filter((x) => x !== id) })),
    });
  }));
}

/* ================= ETAPA 2 — Professores ================= */

function renderProfessores(el, estado, slots, ui, acoes) {
  el.innerHTML = `
    <div class="col">
      <section class="bloco">
        <h3>Professores</h3>
        <p class="nota">Matrícula, nome, disciplinas, disponibilidade e turmas preferidas.</p>
        <div class="acoes">
          <button type="button" class="btn" id="btn-novo-prof"><i data-lucide="plus"></i> Novo professor</button>
          <button type="button" class="btn-fantasma" id="btn-toggle-import"><i data-lucide="sparkles"></i> Importar de um texto</button>
        </div>

        ${mostrarImportacao ? `
          <div class="ia-caixa">
            <p class="rotulo-mini">Cole a lista como ela chegou — o Claude separa matrícula, nome e disciplinas.</p>
            <textarea id="texto-import" rows="5" placeholder="1042 - Ana Ribeiro - Matemática e Física, prefere 9º ano&#10;1043 - Carlos Nunes - História">${esc(rascunhoImportacao)}</textarea>
            <button type="button" class="btn" id="btn-ler-import" ${ui.ocupado ? 'disabled' : ''}>
              ${ui.ocupado === 'Lendo cadastro' ? '<span class="gira-txt"><i data-lucide="loader-2" class="gira"></i> Lendo…</span>' : '<i data-lucide="wand-2"></i> Ler e cadastrar'}
            </button>
          </div>` : ''}

        <div class="lista" id="lista-profs">
          ${estado.professores.map((p, i) => renderFichaProfessor(estado, p, i, slots)).join('') || '<p class="vazio">Nenhum professor ainda.</p>'}
        </div>
      </section>
    </div>`;

  el.querySelector('#btn-novo-prof').addEventListener('click', () => {
    const novo = { matricula: '', nome: '', disciplinas: [], prefTurmas: [], disp: {}, _k: uid() };
    profAberto = estado.professores.length;
    acoes.atualizarEstado({ resultado: null, professores: [...estado.professores, novo] });
  });

  el.querySelector('#btn-toggle-import').addEventListener('click', () => {
    mostrarImportacao = !mostrarImportacao;
    acoes.atualizarUI({});
  });

  const btnLer = el.querySelector('#btn-ler-import');
  if (btnLer) {
    btnLer.addEventListener('click', async () => {
      const textarea = el.querySelector('#texto-import');
      const texto = textarea.value.trim();
      if (!texto) return;
      rascunhoImportacao = texto;
      await acoes.comIA('Lendo cadastro', async () => {
        const resp = await chamarClaude(
          `Disciplinas (id — nome):\n${estado.disciplinas.map((d) => `${d.id} — ${d.nome}`).join('\n') || 'nenhuma'}\n\nTurmas (id — nome):\n${estado.turmas.map((t) => `${t.id} — ${t.nome}`).join('\n') || 'nenhuma'}\n\nTexto:\n${texto}`,
          'Você extrai cadastro de professores de texto livre em português. Responda APENAS um array JSON, sem markdown. Cada item: {"matricula":string,"nome":string,"disciplinas":[ids],"prefTurmas":[ids]}. Use somente ids das listas; sem correspondência clara, array vazio. Sem matrícula no texto, gere uma de 4 dígitos.',
          2000,
        );
        const arr = extrairJSON(resp);
        const ids = new Set(estado.disciplinas.map((d) => d.id)), tids = new Set(estado.turmas.map((t) => t.id));
        const limpos = (Array.isArray(arr) ? arr : []).filter((x) => x && x.nome).map((x) => ({
          matricula: String(x.matricula || uid()).trim(), nome: String(x.nome).trim(),
          disciplinas: (x.disciplinas || []).filter((d) => ids.has(d)),
          prefTurmas: (x.prefTurmas || []).filter((t) => tids.has(t)), disp: {}, _k: uid(),
        }));
        if (!limpos.length) throw new Error('Não identifiquei nenhum professor nesse texto.');
        rascunhoImportacao = '';
        mostrarImportacao = false;
        acoes.atualizarEstado({ resultado: null, professores: [...estado.professores, ...limpos] });
      });
    });
  }

  estado.professores.forEach((p, i) => {
    const ficha = el.querySelector(`[data-ficha="${i}"]`);
    if (!ficha) return;
    ficha.querySelector('.ficha-cab').addEventListener('click', () => {
      profAberto = profAberto === i ? null : i;
      acoes.atualizarUI({});
    });
    if (profAberto !== i) return;

    const upd = (patch) => acoes.atualizarEstado({
      resultado: null,
      professores: estado.professores.map((x, j) => (j === i ? { ...x, ...patch } : x)),
    });

    const inMat = ficha.querySelector('[data-campo="matricula"]');
    const inNome = ficha.querySelector('[data-campo="nome"]');
    inMat.addEventListener('change', (ev) => upd({ matricula: ev.target.value }));
    inNome.addEventListener('change', (ev) => upd({ nome: ev.target.value }));
    enterConfirma(inMat); enterConfirma(inNome);

    ficha.querySelector('[data-rem-prof]').addEventListener('click', () => {
      profAberto = null;
      acoes.atualizarEstado({ resultado: null, professores: estado.professores.filter((_, j) => j !== i) });
    });

    ficha.querySelectorAll('[data-toggle-disc]').forEach((b) => b.addEventListener('click', () => {
      const did = b.dataset.toggleDisc;
      const on = p.disciplinas.includes(did);
      upd({ disciplinas: on ? p.disciplinas.filter((x) => x !== did) : [...p.disciplinas, did] });
    }));
    ficha.querySelectorAll('[data-toggle-pref]').forEach((b) => b.addEventListener('click', () => {
      const tid = b.dataset.togglePref;
      const on = (p.prefTurmas || []).includes(tid);
      upd({ prefTurmas: on ? p.prefTurmas.filter((x) => x !== tid) : [...(p.prefTurmas || []), tid] });
    }));

    ligarDisponibilidade(ficha.querySelector('.disp'), estado, p, (disp) => upd({ disp }));

    ficha.querySelector('[data-liberar-tudo]').addEventListener('click', () => upd({ disp: {} }));
    ficha.querySelector('[data-bloquear-tudo]').addEventListener('click', () => upd({ disp: Object.fromEntries(slots.map((s) => [s.id, false])) }));
  });
}

function renderFichaProfessor(estado, p, i, slots) {
  const livres = slots.filter((s) => p.disp[s.id] !== false).length;
  const aberto = profAberto === i;
  return `
    <div class="ficha" data-ficha="${i}">
      <button type="button" class="ficha-cab">
        <span class="mat">${esc(p.matricula || '····')}</span>
        <span class="ficha-nome">${esc(p.nome || 'sem nome')}</span>
        <span class="ficha-meta">${p.disciplinas.length} disc. · ${livres}/${slots.length}</span>
        <i data-lucide="chevron-down" class="${aberto ? 'vira' : ''}"></i>
      </button>
      ${aberto ? `
        <div class="ficha-corpo">
          <div class="linha-form">
            <label class="campo"><span>Matrícula</span><input class="mono" data-campo="matricula" value="${esc(p.matricula)}" placeholder="1042"></label>
            <label class="campo larga"><span>Nome</span><input data-campo="nome" value="${esc(p.nome)}" placeholder="Ana Ribeiro"></label>
            <button type="button" class="btn-icone" data-rem-prof><i data-lucide="trash-2"></i></button>
          </div>

          <p class="rotulo-mini">Disciplinas que leciona</p>
          <div class="chips">
            ${estado.disciplinas.map((d) => `<button type="button" class="chip${p.disciplinas.includes(d.id) ? ' on' : ''}" data-toggle-disc="${d.id}">${esc(d.nome)}</button>`).join('') || '<span class="vazio">Cadastre disciplinas antes.</span>'}
          </div>

          <p class="rotulo-mini">Turmas preferidas</p>
          <div class="chips">
            ${estado.turmas.map((t) => `<button type="button" class="chip${(p.prefTurmas || []).includes(t.id) ? ' on pref' : ''}" data-toggle-pref="${t.id}">${esc(t.nome)}</button>`).join('') || '<span class="vazio">Cadastre turmas antes.</span>'}
          </div>

          <p class="rotulo-mini">Disponibilidade — arraste para marcar os tempos livres</p>
          ${gradeDisponibilidadeHtml(estado, p)}
          <div class="acoes">
            <button type="button" class="btn-mini" data-liberar-tudo>Liberar tudo</button>
            <button type="button" class="btn-mini" data-bloquear-tudo>Bloquear tudo</button>
          </div>
        </div>` : ''}
    </div>`;
}

function gradeDisponibilidadeHtml(estado, p) {
  let linhas = '';
  estado.horarios.forEach((h, ai) => {
    linhas += `<div class="disp-hora">${h.inicio}</div>`;
    estado.dias.forEach((_, di) => {
      const id = `${di}-${ai}`;
      if (h.intervalo) { linhas += '<div class="cel-intervalo"></div>'; return; }
      const livre = p.disp[id] !== false;
      linhas += `<div class="cel${livre ? ' livre' : ''}" data-slot="${id}"></div>`;
    });
  });
  return `
    <div class="disp" style="grid-template-columns:52px repeat(${estado.dias.length},1fr)">
      <div></div>
      ${estado.dias.map((d) => `<div class="disp-cab">${esc(d.slice(0, 3))}</div>`).join('')}
      ${linhas}
    </div>`;
}

// Pintura por arraste: não re-renderiza a árvore inteira durante o gesto —
// só troca a classe na hora e confirma o estado final no pointerup.
function ligarDisponibilidade(container, estado, p, onCommit) {
  if (!container) return;
  if (pararPintura) { window.removeEventListener('pointerup', pararPintura); window.removeEventListener('pointercancel', pararPintura); pararPintura = null; }

  let pintando = null;
  const dispLocal = { ...p.disp };

  const parar = () => {
    if (pintando === null) return;
    pintando = null;
    onCommit(dispLocal);
  };
  pararPintura = parar;
  window.addEventListener('pointerup', parar);
  window.addEventListener('pointercancel', parar);

  container.querySelectorAll('[data-slot]').forEach((cel) => {
    const id = cel.dataset.slot;
    cel.addEventListener('pointerdown', (ev) => {
      ev.preventDefault();
      const livreAtual = dispLocal[id] !== false;
      pintando = !livreAtual;
      dispLocal[id] = pintando;
      cel.classList.toggle('livre', pintando);
    });
    cel.addEventListener('pointerenter', () => {
      if (pintando === null) return;
      dispLocal[id] = pintando;
      cel.classList.toggle('livre', pintando);
    });
  });
}

/* ================= ETAPA 3 — Currículo ================= */

function renderCurriculo(el, estado, val, ui, acoes) {
  const T = val.totalTempos;

  el.innerHTML = `
    <div class="col">
      <section class="bloco">
        <h3>Quantas aulas de cada disciplina por semana</h3>
        <p class="nota">Cada turma precisa somar exatamente ${T} — é o que garante zero tempo vago.</p>
        <div class="acoes">
          <button type="button" class="btn-fantasma" id="btn-sugerir-carga" ${ui.ocupado ? 'disabled' : ''}>
            ${ui.ocupado === 'Sugerindo carga' ? '<span class="gira-txt"><i data-lucide="loader-2" class="gira"></i> Sugerindo…</span>' : '<i data-lucide="sparkles"></i> Sugerir carga horária'}
          </button>
          <button type="button" class="btn-fantasma" id="btn-distribuir" ${ui.ocupado ? 'disabled' : ''}>
            ${ui.ocupado === 'Distribuindo professores' ? '<span class="gira-txt"><i data-lucide="loader-2" class="gira"></i> Distribuindo…</span>' : '<i data-lucide="sparkles"></i> Distribuir professores'}
          </button>
        </div>

        ${estado.turmas.length ? estado.turmas.map((t) => renderTurmaCurriculo(estado, t, T)).join('') : '<p class="vazio">Cadastre turmas e disciplinas primeiro.</p>'}
      </section>
    </div>`;

  el.querySelector('#btn-sugerir-carga')?.addEventListener('click', async () => {
    await acoes.comIA('Sugerindo carga', async () => {
      const resp = await chamarClaude(
        acoes.ctxTexto() + `\n\nProponha a carga semanal de cada disciplina para cada turma. A soma de cada turma deve dar EXATAMENTE ${T}.`,
        `Você é coordenador pedagógico brasileiro. Distribua as aulas semanais por disciplina seguindo a prática usual da BNCC (mais Português e Matemática, menos Arte e Educação Física). A soma por turma tem de ser exatamente ${T}. Responda APENAS um array JSON, sem markdown: [{"turma":"<id>","disciplina":"<id>","carga":<inteiro>}].`,
        2500,
      );
      const arr = extrairJSON(resp);
      const g = { ...estado.grade };
      (Array.isArray(arr) ? arr : []).forEach((x) => {
        const k = `${x.turma}|${x.disciplina}`;
        if (estado.turmas.some((t) => t.id === x.turma) && estado.disciplinas.some((d) => d.id === x.disciplina))
          g[k] = { prof: '', ...(g[k] || {}), carga: Math.max(0, Number(x.carga) || 0) };
      });
      acoes.atualizarEstado({ grade: g, resultado: null });
      acoes.atualizarUI({ resposta: `Carga sugerida. Confira os totais — se alguma turma não fechar ${T}, use "Fechar em ${T}".` });
    });
  });

  el.querySelector('#btn-distribuir')?.addEventListener('click', async () => {
    await acoes.comIA('Distribuindo professores', async () => {
      const resp = await chamarClaude(
        acoes.ctxTexto() + '\n\nDistribua o professor responsável por cada par turma/disciplina com carga maior que zero.',
        'Você é coordenador pedagógico. Atribua um professor a cada par turma+disciplina com carga. Regras: o professor precisa lecionar a disciplina; respeite as turmas preferidas quando possível; equilibre a carga; nunca dê a um professor mais aulas do que os tempos livres dele. Responda APENAS um array JSON, sem markdown: [{"turma":"<id>","disciplina":"<id>","matricula":"<matrícula>"}].',
        2500,
      );
      const arr = extrairJSON(resp);
      const mats = new Set(estado.professores.map((p) => p.matricula));
      const g = { ...estado.grade };
      (Array.isArray(arr) ? arr : []).forEach((x) => {
        const k = `${x.turma}|${x.disciplina}`;
        if (g[k] && mats.has(String(x.matricula))) g[k] = { ...g[k], prof: String(x.matricula) };
      });
      acoes.atualizarEstado({ grade: g, resultado: null });
      acoes.atualizarUI({ resposta: 'Professores distribuídos. O solver ainda vai verificar todas as regras duras.' });
    });
  });

  estado.turmas.forEach((t) => {
    const bloco = el.querySelector(`[data-turma-curr="${t.id}"]`);
    if (!bloco) return;
    bloco.querySelectorAll('[data-carga]').forEach((input) => {
      input.addEventListener('change', () => {
        const did = input.dataset.carga;
        const chave = `${t.id}|${did}`;
        const atual = estado.grade[chave] || { carga: 0, prof: '' };
        const grade = { ...estado.grade, [chave]: { ...atual, carga: Math.max(0, Number(input.value) || 0) } };
        acoes.atualizarEstado({ grade, resultado: null });
      });
    });
    bloco.querySelectorAll('[data-prof-select]').forEach((select) => {
      select.addEventListener('change', () => {
        const did = select.dataset.profSelect;
        const chave = `${t.id}|${did}`;
        const atual = estado.grade[chave] || { carga: 0, prof: '' };
        const grade = { ...estado.grade, [chave]: { ...atual, prof: select.value } };
        acoes.atualizarEstado({ grade, resultado: null });
      });
    });
    const btnFechar = bloco.querySelector('[data-fechar-turma]');
    if (btnFechar) btnFechar.addEventListener('click', () => {
      const grade = fecharCargaEmT(estado, t.id, T);
      acoes.atualizarEstado({ grade, resultado: null });
    });
  });
}

function renderTurmaCurriculo(estado, t, T) {
  const soma = somaTurma(estado, t.id);
  const estadoSaldo = soma === T ? 'exato' : soma > T ? 'excesso' : 'falta';
  return `
    <div class="turma-bloco" data-turma-curr="${t.id}">
      <div class="turma-cab">
        <h4>${esc(t.nome)}</h4>
        <div class="turma-dir">
          <span class="saldo ${estadoSaldo}">${soma} / ${T}</span>
          ${soma !== T ? `<button type="button" class="btn-mini" data-fechar-turma><i data-lucide="scale"></i> Fechar em ${T}</button>` : ''}
        </div>
      </div>
      <div class="rolagem">
        <table class="tab">
          <thead><tr><th>Disciplina</th><th style="width:84px">Aulas</th><th style="width:186px">Professor</th></tr></thead>
          <tbody>
            ${estado.disciplinas.map((d) => {
              const c = estado.grade[`${t.id}|${d.id}`] || { carga: 0, prof: '' };
              const aptos = estado.professores.filter((p) => p.disciplinas.includes(d.id));
              return `
                <tr>
                  <td>${esc(d.nome)}</td>
                  <td><input type="number" min="0" max="${T}" value="${c.carga || 0}" data-carga="${d.id}"></td>
                  <td>
                    <select data-prof-select="${d.id}" ${!Number(c.carga) ? 'disabled' : ''}>
                      <option value="">${aptos.length ? '— escolher —' : 'ninguém leciona'}</option>
                      ${aptos.map((p) => `<option value="${p.matricula}" ${c.prof === p.matricula ? 'selected' : ''}>${esc(p.matricula)} · ${esc(p.nome)}${(p.prefTurmas || []).includes(t.id) ? ' ★' : ''}</option>`).join('')}
                    </select>
                  </td>
                </tr>`;
            }).join('')}
          </tbody>
        </table>
      </div>
    </div>`;
}

/* ================= ETAPA 4 — Quadro ================= */

function renderQuadro(el, estado, val, ui, acoes) {
  const res = estado.resultado;
  const D = Object.fromEntries(estado.disciplinas.map((d) => [d.id, d.nome]));
  const P = Object.fromEntries(estado.professores.map((p) => [p.matricula, p.nome]));
  const T = Object.fromEntries(estado.turmas.map((t) => [t.id, t.nome]));
  const celulas = {};
  if (res) res.aulas.forEach((a) => { celulas[`${a.turma}|${res.atrib[a.id]}`] = a; });
  const falhas = res ? conferirFalhas(res, estado) : [];

  if (!alvoQuadro) alvoQuadro = vistaQuadro === 'turma' ? estado.turmas[0]?.id : estado.professores[0]?.matricula;

  el.innerHTML = `
    <div class="col">
      <section class="bloco">
        <h3>Montar o quadro</h3>
        <p class="nota">Cada turma recebe um professor em todos os tempos — vaga é impossível por construção.</p>
        <div class="acoes">
          <button type="button" class="btn grande" id="btn-gerar" ${ui.ocupado || val.erros.length > 0 ? 'disabled' : ''}>
            ${ui.ocupado === 'Montando' ? '<span class="gira-txt"><i data-lucide="loader-2" class="gira"></i> Montando…</span>' : 'Gerar grade horária'}
          </button>
          <button type="button" class="btn-fantasma" id="btn-diagnosticar" ${ui.ocupado ? 'disabled' : ''}>
            ${ui.ocupado === 'Analisando' ? '<span class="gira-txt"><i data-lucide="loader-2" class="gira"></i> Analisando…</span>' : '<i data-lucide="sparkles"></i> O que travou?'}
          </button>
          ${res ? `<button type="button" class="btn-fantasma" id="btn-revisar" ${ui.ocupado ? 'disabled' : ''}>
            ${ui.ocupado === 'Revisando' ? '<span class="gira-txt"><i data-lucide="loader-2" class="gira"></i> Revisando…</span>' : '<i data-lucide="sparkles"></i> Revisão pedagógica'}
          </button>` : ''}
          ${res ? '<button type="button" class="btn-solido" id="btn-exportar"><i data-lucide="download"></i> Baixar Excel</button>' : ''}
        </div>
        ${res ? `<div class="selo"><i data-lucide="check"></i><span>${res.aulas.length} aulas alocadas · ${falhas.length === 0 ? 'zero tempos vagos, zero conflitos' : esc(falhas.join(' '))} · qualidade ${res.pontuacao}</span></div>` : ''}
      </section>

      ${res ? `
        <div class="quadro">
          <div class="quadro-topo">
            <div class="segm">
              <button type="button" class="${vistaQuadro === 'turma' ? 'on' : ''}" data-vista="turma">Por turma</button>
              <button type="button" class="${vistaQuadro === 'prof' ? 'on' : ''}" data-vista="prof">Por professor</button>
            </div>
            <select class="sel-quadro" id="sel-foco">
              ${vistaQuadro === 'turma'
                ? estado.turmas.map((t) => `<option value="${t.id}" ${alvoQuadro === t.id ? 'selected' : ''}>${esc(t.nome)}</option>`).join('')
                : estado.professores.map((p) => `<option value="${p.matricula}" ${alvoQuadro === p.matricula ? 'selected' : ''}>${esc(p.matricula)} · ${esc(p.nome)}</option>`).join('')}
            </select>
          </div>
          <div class="rolagem">
            <div class="malha" style="grid-template-columns:74px repeat(${estado.dias.length},minmax(92px,1fr))">
              <div class="mh"></div>
              ${estado.dias.map((d) => `<div class="mh">${esc(d.slice(0, 3))}</div>`).join('')}
              ${estado.horarios.map((h, ai) => `
                <div class="mhora"><b>${h.inicio}</b><span>${h.fim}</span></div>
                ${estado.dias.map((_, di) => {
                  if (h.intervalo) return `<div class="mcel intervalo">${esc(h.rotulo || 'Intervalo')}</div>`;
                  const id = `${di}-${ai}`;
                  if (vistaQuadro === 'turma') {
                    const a = celulas[`${alvoQuadro}|${id}`];
                    return `<div class="mcel${a ? ' cheia' : ' erro'}">${a ? `<b>${esc(D[a.disc])}</b><span>${esc(P[a.prof])}</span>` : '<span class="vaga">vago</span>'}</div>`;
                  }
                  const achou = res.aulas.find((a) => a.prof === alvoQuadro && res.atrib[a.id] === id);
                  const p = estado.professores.find((x) => x.matricula === alvoQuadro);
                  const bloqueada = p && p.disp[id] === false;
                  return `<div class="mcel${achou ? ' cheia' : bloqueada ? ' bloqueada' : ''}">${achou ? `<b>${esc(D[achou.disc])}</b><span>${esc(T[achou.turma])}</span>` : `<span class="vaga">${bloqueada ? 'indisp.' : 'livre'}</span>`}</div>`;
                }).join('')}`).join('')}
            </div>
          </div>
        </div>` : ''}
    </div>`;

  el.querySelector('#btn-gerar')?.addEventListener('click', () => acoes.gerar());

  el.querySelector('#btn-diagnosticar')?.addEventListener('click', async () => {
    await acoes.comIA('Analisando', async () => {
      const resp = await chamarClaude(
        acoes.ctxTexto() + `\n\nVerificador:\n${val.erros.join('\n') || 'nenhum erro'}\nAtenções:\n${val.avisos.join('\n') || 'nenhuma'}\n\nO solver ${res ? 'montou a grade' : 'NÃO conseguiu montar a grade'}.`,
        'Você é coordenador pedagógico experiente. Em português, explique direto o que impede esta grade de fechar sem tempo vago e liste no máximo 4 mudanças concretas e numeradas. Sem markdown, sem preâmbulo. Máximo 180 palavras.',
        900,
      );
      acoes.atualizarUI({ resposta: resp.trim() });
    });
  });

  el.querySelector('#btn-revisar')?.addEventListener('click', async () => {
    if (!res) return;
    await acoes.comIA('Revisando', async () => {
      const resumo = estado.turmas.map((t) => `${t.nome}: ` + estado.dias.map((dia, di) =>
        `${dia}=[` + estado.horarios.map((h, ai) => (h.intervalo ? null : (celulas[`${t.id}|${di}-${ai}`] ? D[celulas[`${t.id}|${di}-${ai}`].disc] : '?'))).filter(Boolean).join(', ') + ']').join(' | ')).join('\n');
      const resp = await chamarClaude(
        acoes.ctxTexto() + '\n\nGrade gerada (regras duras já verificadas):\n' + resumo,
        'Você é coordenador pedagógico. Avalie a qualidade pedagógica desta grade válida: distribuição na semana, matérias pesadas no fim do turno, sequências longas, equilíbrio entre turmas. Em português, sem markdown: um parágrafo curto e no máximo 3 ajustes numerados. Máximo 180 palavras.',
        900,
      );
      acoes.atualizarUI({ resposta: resp.trim() });
    });
  });

  el.querySelector('#btn-exportar')?.addEventListener('click', () => exportarExcel(estado));

  el.querySelectorAll('[data-vista]').forEach((b) => b.addEventListener('click', () => {
    vistaQuadro = b.dataset.vista;
    alvoQuadro = null;
    acoes.atualizarUI({});
  }));
  el.querySelector('#sel-foco')?.addEventListener('change', (ev) => {
    alvoQuadro = ev.target.value;
    acoes.atualizarUI({});
  });
}

// versão local (não exportada por core.js para o app.js, mas precisamos aqui pra mostrar a mensagem-resumo)
function conferirFalhas(res, e) {
  if (!res || !res.ok) return [];
  const f = [], vT = new Set(), vP = new Set();
  res.aulas.forEach((a) => {
    const s = res.atrib[a.id];
    if (vT.has(a.turma + '@' + s)) f.push('Duas aulas na mesma turma no mesmo tempo.');
    if (vP.has(a.prof + '@' + s)) f.push('Professor em duas turmas no mesmo tempo.');
    vT.add(a.turma + '@' + s); vP.add(a.prof + '@' + s);
    const p = e.professores.find((x) => x.matricula === a.prof);
    if (p && p.disp[s] === false) f.push(`${p.nome} alocado fora da disponibilidade.`);
  });
  const slots = gerarSlots(e.dias, e.horarios);
  let vagos = 0;
  e.turmas.forEach((t) => slots.forEach((s) => { if (!vT.has(t.id + '@' + s.id)) vagos++; }));
  if (vagos) f.push(`${vagos} tempo(s) vago(s).`);
  return [...new Set(f)];
}
