// Fala com a API Java local (backend/), que repassa a chamada ao Claude.
// Se o frontend estiver hospedado num lugar diferente do backend, defina
// <meta name="api-base" content="http://host:porta"> no index.html.

function baseUrl() {
  const meta = document.querySelector('meta[name="api-base"]');
  return (meta && meta.content) ? meta.content.replace(/\/$/, '') : '';
}

export async function statusApi() {
  try {
    const r = await fetch(baseUrl() + '/api/claude/status');
    if (!r.ok) return { configurado: false };
    return await r.json();
  } catch {
    return { configurado: false, offline: true };
  }
}

export async function chamarClaude(prompt, system, maxTokens = 1400) {
  const resposta = await fetch(baseUrl() + '/api/claude/mensagem', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt, system, maxTokens }),
  });
  const dados = await resposta.json().catch(() => ({}));
  if (!resposta.ok) {
    throw new Error(dados.erro || `A chamada ao servidor falhou (HTTP ${resposta.status}).`);
  }
  return dados.texto || '';
}
