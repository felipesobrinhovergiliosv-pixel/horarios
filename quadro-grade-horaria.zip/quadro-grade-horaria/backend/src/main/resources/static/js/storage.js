// Persistência simples em localStorage — cada navegador guarda seu próprio cadastro.
const CHAVE = 'quadro:estado:v1';

export function salvarEstado(estado) {
  try { localStorage.setItem(CHAVE, JSON.stringify(estado)); } catch { /* armazenamento indisponível */ }
}

export function carregarEstado() {
  try {
    const s = localStorage.getItem(CHAVE);
    return s ? JSON.parse(s) : null;
  } catch { return null; }
}

export function limparEstado() {
  try { localStorage.removeItem(CHAVE); } catch { /* nada a fazer */ }
}
