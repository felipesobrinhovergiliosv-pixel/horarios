// ============================================================
// QUADRO — núcleo do organizador de grade horária escolar
// Regra dura: nenhuma turma pode ter tempo vago.
// Solver: emparelhamento bipartido (Kuhn) tempo a tempo.
// ============================================================

export const DIAS_BASE = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
export const TURNOS = ['Manhã', 'Tarde', 'Noite'];

export const uid = () => Math.random().toString(36).slice(2, 9);

export const paraMin = (h) => {
  const [a, b] = String(h).split(':').map(Number);
  return (a || 0) * 60 + (b || 0);
};
export const paraHora = (m) =>
  `${String(Math.floor(m / 60) % 24).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;

export function construirHorarios(esc) {
  const linhas = [];
  let t = paraMin(esc.inicio);
  const total = Math.max(1, Number(esc.aulasPorDia) || 1);
  for (let i = 1; i <= total; i++) {
    linhas.push({ inicio: paraHora(t), fim: paraHora(t + Number(esc.duracao)), intervalo: false, rotulo: `${i}ª aula` });
    t += Number(esc.duracao);
    (esc.intervalos || []).filter((x) => Number(x.depois) === i).forEach((iv) => {
      linhas.push({ inicio: paraHora(t), fim: paraHora(t + Number(iv.minutos)), intervalo: true, rotulo: iv.rotulo || 'Intervalo' });
      t += Number(iv.minutos);
    });
  }
  return linhas;
}

export const ESCOLA_PADRAO = {
  nome: '', ano: String(new Date().getFullYear()), turno: 'Manhã',
  inicio: '07:00', duracao: 50, aulasPorDia: 5,
  intervalos: [{ depois: 3, minutos: 20, rotulo: 'Recreio' }],
};

export const ESTADO_VAZIO = {
  escola: { ...ESCOLA_PADRAO, intervalos: [{ depois: 3, minutos: 20, rotulo: 'Recreio' }] },
  dias: ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta'],
  horarios: construirHorarios(ESCOLA_PADRAO),
  turmas: [], disciplinas: [], professores: [], grade: {},
  pesos: { repetido: 6, janela: 4, preferencia: 3 },
  resultado: null,
};

/* ---------------- escola de exemplo, já cadastrada ---------------- */

export function exemplo() {
  const escola = {
    nome: 'E.M. Cecília Meireles', ano: String(new Date().getFullYear()), turno: 'Manhã',
    inicio: '07:00', duracao: 50, aulasPorDia: 5,
    intervalos: [{ depois: 3, minutos: 20, rotulo: 'Recreio' }],
  };
  const dias = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta'];
  const horarios = construirHorarios(escola);
  const linhasAula = horarios.map((h, i) => (h.intervalo ? null : i)).filter((x) => x !== null);

  const T = ['6º ano A', '6º ano B', '7º ano A', '8º ano A'].map((nome) => ({ id: uid(), nome }));
  const nomes = ['Português', 'Matemática', 'História', 'Geografia', 'Ciências', 'Inglês', 'Arte', 'Educação Física'];
  const D = nomes.map((nome) => ({ id: uid(), nome }));
  const d = Object.fromEntries(D.map((x, i) => [nomes[i], x.id]));

  const bloq = (pares) => Object.fromEntries(pares.map((p) => [p, false]));
  const diaTodo = (di) => linhasAula.map((ai) => `${di}-${ai}`);
  const primeiro = () => dias.map((_, di) => `${di}-${linhasAula[0]}`);

  const P = [
    { matricula: '1001', nome: 'Ana Ribeiro', disciplinas: [d['Matemática'], d['Ciências']], prefTurmas: [T[3].id], disp: {} },
    { matricula: '1002', nome: 'Bruno Carvalho', disciplinas: [d['Português']], prefTurmas: [T[0].id, T[1].id], disp: {} },
    { matricula: '1003', nome: 'Carla Mendes', disciplinas: [d['História'], d['Geografia']], prefTurmas: [T[2].id], disp: {} },
    { matricula: '1004', nome: 'Diego Lopes', disciplinas: [d['Geografia'], d['História']], prefTurmas: [], disp: {} },
    { matricula: '1005', nome: 'Eduarda Pinto', disciplinas: [d['Ciências'], d['Matemática']], prefTurmas: [T[2].id], disp: {} },
    { matricula: '1006', nome: 'Felipe Souza', disciplinas: [d['Inglês'], d['Arte']], prefTurmas: [], disp: bloq(primeiro()) },
    { matricula: '1007', nome: 'Gabriela Nunes', disciplinas: [d['Arte'], d['Português']], prefTurmas: [T[0].id], disp: bloq(diaTodo(0)) },
    { matricula: '1008', nome: 'Henrique Alves', disciplinas: [d['Educação Física']], prefTurmas: [], disp: bloq(diaTodo(4)) },
  ].map((p) => ({ ...p, _k: uid() }));

  const carga = { 'Português': 5, 'Matemática': 5, 'História': 3, 'Geografia': 3, 'Ciências': 3, 'Inglês': 2, 'Arte': 2, 'Educação Física': 2 };
  const resp = {
    'Português': ['1002', '1002', '1002', '1007'],
    'Matemática': ['1001', '1001', '1005', '1001'],
    'História': ['1003', '1003', '1003', '1004'],
    'Geografia': ['1004', '1004', '1004', '1003'],
    'Ciências': ['1005', '1005', '1005', '1005'],
    'Inglês': ['1006', '1006', '1006', '1006'],
    'Arte': ['1007', '1007', '1006', '1006'],
    'Educação Física': ['1008', '1008', '1008', '1008'],
  };
  const grade = {};
  T.forEach((t, ti) => nomes.forEach((n) => { grade[`${t.id}|${d[n]}`] = { carga: carga[n], prof: resp[n][ti] }; }));

  return { ...ESTADO_VAZIO, escola, dias, horarios, turmas: T, disciplinas: D, professores: P, grade, resultado: null };
}

/* ---------------- núcleo de slots e aulas ---------------- */

export function gerarSlots(dias, horarios) {
  const s = [];
  for (let di = 0; di < dias.length; di++)
    for (let ai = 0; ai < horarios.length; ai++)
      if (!horarios[ai].intervalo) s.push({ id: `${di}-${ai}`, d: di, a: ai });
  return s;
}

export const nomeSlot = (e, s) => `${e.dias[s.d]}, ${e.horarios[s.a]?.rotulo || `${s.a + 1}ª`}`;

export function montarAulas(e) {
  const aulas = [];
  e.turmas.forEach((t) => e.disciplinas.forEach((dis) => {
    const c = e.grade[`${t.id}|${dis.id}`];
    if (!c || !Number(c.carga) || !c.prof) return;
    for (let i = 0; i < Number(c.carga); i++)
      aulas.push({ id: `${t.id}|${dis.id}|${i}`, turma: t.id, disc: dis.id, prof: c.prof });
  }));
  return aulas;
}

export const somaTurma = (e, tid) =>
  e.disciplinas.reduce((s, d) => s + Number(e.grade[`${tid}|${d.id}`]?.carga || 0), 0);

/* ---------------- fechar a carga de uma turma em T tempos ---------------- */

export function fecharCargaEmT(estado, tid, total) {
  const g = { ...estado.grade };
  const chaves = estado.disciplinas.map((d) => `${tid}|${d.id}`);
  const ativas = chaves.filter((k) => Number(g[k]?.carga) > 0);
  const alvo = ativas.length ? ativas : chaves;
  alvo.forEach((k) => { if (!g[k]) g[k] = { carga: 0, prof: '' }; });
  let soma = chaves.reduce((s, k) => s + Number(g[k]?.carga || 0), 0);
  let guarda = 0;
  while (soma !== total && guarda++ < 500) {
    if (soma < total) {
      const k = alvo.reduce((m, x) => (Number(g[x].carga || 0) < Number(g[m].carga || 0) ? x : m), alvo[0]);
      g[k] = { ...g[k], carga: Number(g[k].carga || 0) + 1 };
      soma++;
    } else {
      const cand = alvo.filter((x) => Number(g[x].carga || 0) > 1);
      if (!cand.length) break;
      const k = cand.reduce((m, x) => (Number(g[x].carga) > Number(g[m].carga) ? x : m), cand[0]);
      g[k] = { ...g[k], carga: Number(g[k].carga) - 1 };
      soma--;
    }
  }
  return g;
}

/* ---------------- validação ---------------- */

export function validar(e) {
  const erros = [], avisos = [];
  const slots = gerarSlots(e.dias, e.horarios);
  const total = slots.length;
  const profs = Object.fromEntries(e.professores.map((p) => [p.matricula, p]));

  if (!e.turmas.length) erros.push('Nenhuma turma cadastrada.');
  if (!e.disciplinas.length) erros.push('Nenhuma disciplina cadastrada.');
  if (!e.professores.length) erros.push('Nenhum professor cadastrado.');
  if (!total) erros.push('A semana não tem nenhum tempo de aula.');
  if (erros.length) return { erros, avisos, totalTempos: total, cargaProf: {} };

  const cargaProf = {};
  e.turmas.forEach((t) => {
    let soma = 0;
    e.disciplinas.forEach((dis) => {
      const c = e.grade[`${t.id}|${dis.id}`];
      if (!c || !Number(c.carga)) return;
      soma += Number(c.carga);
      if (!c.prof) { erros.push(`${dis.nome} na ${t.nome} tem ${c.carga} aulas mas nenhum professor responsável.`); return; }
      const p = profs[c.prof];
      if (!p) { erros.push(`A matrícula ${c.prof} (${dis.nome} / ${t.nome}) não existe no cadastro.`); return; }
      if (!p.disciplinas.includes(dis.id)) erros.push(`${p.nome} está em ${dis.nome} na ${t.nome}, mas não leciona essa disciplina.`);
      cargaProf[c.prof] = (cargaProf[c.prof] || 0) + Number(c.carga);
      if (Number(c.carga) > e.dias.length) avisos.push(`${dis.nome} tem ${c.carga} aulas na ${t.nome} em ${e.dias.length} dias — haverá repetição no mesmo dia.`);
    });
    if (soma !== total) erros.push(`${t.nome} soma ${soma} de ${total} tempos. Como não pode ficar tempo vago, a soma precisa ser exatamente ${total} — ${soma < total ? `faltam ${total - soma}` : `sobram ${soma - total}`}.`);
  });

  Object.entries(cargaProf).forEach(([mat, carga]) => {
    const p = profs[mat];
    if (!p) return;
    const disp = slots.filter((s) => p.disp[s.id] !== false).length;
    if (carga > disp) erros.push(`${p.nome} tem ${carga} aulas atribuídas mas só ${disp} tempos disponíveis.`);
    else if (carga === disp) avisos.push(`${p.nome} ocupa 100% da disponibilidade — a grade fica rígida.`);
  });

  const nT = e.turmas.length;
  const bloqueios = [];
  slots.forEach((s) => {
    const livres = e.professores.filter((p) => p.disp[s.id] !== false && cargaProf[p.matricula] > 0);
    if (livres.length < nT) bloqueios.push(`${nomeSlot(e, s)}: só ${livres.length} professor(es) disponível(is) para ${nT} turmas.`);
    e.turmas.forEach((t) => {
      const tem = e.professores.some((p) => p.disp[s.id] !== false &&
        e.disciplinas.some((d) => { const c = e.grade[`${t.id}|${d.id}`]; return c && Number(c.carga) && c.prof === p.matricula; }));
      if (!tem) bloqueios.push(`${t.nome} não tem nenhum professor disponível em ${nomeSlot(e, s)}.`);
    });
  });
  [...new Set(bloqueios)].slice(0, 6).forEach((b) => erros.push(b));

  return { erros, avisos, totalTempos: total, cargaProf };
}

/* ---------------- solver: emparelhamento bipartido por tempo (Kuhn) ---------------- */

function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function casar(ordemTurmas, cand) {
  const par = new Map();
  const tenta = (t, visto) => {
    for (const p of cand.get(t)) {
      if (visto.has(p)) continue;
      visto.add(p);
      const atual = par.get(p);
      if (atual === undefined || tenta(atual, visto)) { par.set(p, t); return true; }
    }
    return false;
  };
  for (const t of ordemTurmas) if (!tenta(t, new Set())) return null;
  const res = new Map();
  par.forEach((t, p) => res.set(t, p));
  return res;
}

function tentativa(e, slots, aulas, semente) {
  const rnd = mulberry32(semente * 2654435761 + 97);
  const turmas = e.turmas.map((t) => t.id);
  const profs = e.professores;

  const dispDe = {};
  profs.forEach((p) => { dispDe[p.matricula] = new Set(slots.filter((s) => p.disp[s.id] !== false).map((s) => s.id)); });

  const deve = new Map();
  const deveProf = new Map();
  aulas.forEach((a) => {
    deve.set(a.turma + '|' + a.prof, (deve.get(a.turma + '|' + a.prof) || 0) + 1);
    deveProf.set(a.prof, (deveProf.get(a.prof) || 0) + 1);
  });

  let ordem = slots.slice();
  if (semente === 1) ordem.sort((x, y) => profs.filter((p) => p.disp[x.id] !== false).length - profs.filter((p) => p.disp[y.id] !== false).length);
  else if (semente > 1) ordem.sort(() => rnd() - 0.5);

  const restaDisp = new Map();
  profs.forEach((p) => restaDisp.set(p.matricula, ordem.filter((s) => dispDe[p.matricula].has(s.id)).length));

  const plano = {};
  for (const s of ordem) {
    const cand = new Map();
    for (const t of turmas) {
      const lista = [];
      for (const p of profs) {
        if ((deve.get(t + '|' + p.matricula) || 0) > 0 && dispDe[p.matricula].has(s.id)) lista.push(p.matricula);
      }
      if (!lista.length) return { falha: `${e.turmas.find((x) => x.id === t).nome} ficaria sem professor em ${nomeSlot(e, s)}.` };
      lista.sort((a, b) => {
        const ua = (deveProf.get(a) || 0) / Math.max(1, restaDisp.get(a));
        const ub = (deveProf.get(b) || 0) / Math.max(1, restaDisp.get(b));
        if (Math.abs(ua - ub) > 0.001) return ub - ua;
        const da = deve.get(t + '|' + a) || 0, db = deve.get(t + '|' + b) || 0;
        return db - da || rnd() - 0.5;
      });
      cand.set(t, lista);
    }
    const ordemT = turmas.slice().sort((a, b) => cand.get(a).length - cand.get(b).length);
    const m = casar(ordemT, cand);
    if (!m || m.size < turmas.length) return { falha: `Não há professores distintos suficientes em ${nomeSlot(e, s)}.` };

    plano[s.id] = m;
    m.forEach((p, t) => {
      deve.set(t + '|' + p, deve.get(t + '|' + p) - 1);
      deveProf.set(p, deveProf.get(p) - 1);
    });
    profs.forEach((p) => { if (dispDe[p.matricula].has(s.id)) restaDisp.set(p.matricula, restaDisp.get(p.matricula) - 1); });
  }

  const slotsDoPar = {};
  Object.entries(plano).forEach(([sid, m]) => m.forEach((p, t) => {
    const k = t + '|' + p;
    if (!slotsDoPar[k]) slotsDoPar[k] = [];
    slotsDoPar[k].push(sid);
  }));

  const aulasDoPar = {};
  aulas.forEach((a) => { const k = a.turma + '|' + a.prof; if (!aulasDoPar[k]) aulasDoPar[k] = []; aulasDoPar[k].push(a); });

  const atrib = {};
  Object.entries(aulasDoPar).forEach(([k, lista]) => {
    const sids = (slotsDoPar[k] || []).slice().sort((x, y) => {
      const [d1, a1] = x.split('-').map(Number), [d2, a2] = y.split('-').map(Number);
      return d1 - d2 || a1 - a2;
    });
    const filas = {};
    lista.forEach((a) => { if (!filas[a.disc]) filas[a.disc] = []; filas[a.disc].push(a); });
    const ordenada = [];
    const chaves = Object.keys(filas).sort((x, y) => filas[y].length - filas[x].length);
    let sobrou = true;
    while (sobrou) {
      sobrou = false;
      chaves.forEach((c) => { if (filas[c].length) { ordenada.push(filas[c].shift()); sobrou = true; } });
    }
    ordenada.forEach((a, i) => { if (sids[i]) atrib[a.id] = sids[i]; });
  });

  if (Object.keys(atrib).length !== aulas.length) return { falha: 'Falha interna na distribuição das disciplinas.' };
  return { atrib };
}

function pontuar(atrib, aulas, e) {
  const P = e.pesos;
  const profs = Object.fromEntries(e.professores.map((p) => [p.matricula, p]));
  const reais = e.horarios.map((h, i) => (h.intervalo ? null : i)).filter((x) => x !== null);
  let s = 0;
  const porDia = new Map(), porProf = new Map();
  aulas.forEach((a) => {
    const [di, ai] = atrib[a.id].split('-').map(Number);
    const k = `${a.turma}|${a.disc}|${di}`;
    porDia.set(k, (porDia.get(k) || 0) + 1);
    if (!porProf.has(a.prof)) porProf.set(a.prof, new Map());
    const md = porProf.get(a.prof);
    if (!md.has(di)) md.set(di, []);
    md.get(di).push(ai);
    const p = profs[a.prof];
    if (p && (p.prefTurmas || []).includes(a.turma)) s += P.preferencia;
  });
  porDia.forEach((n) => { if (n > 1) s -= P.repetido * (n - 1); });
  porProf.forEach((md) => md.forEach((l) => {
    const min = Math.min(...l), max = Math.max(...l);
    s -= P.janela * Math.max(0, reais.filter((i) => i > min && i < max).length - (l.length - 2));
  }));
  return s;
}

function otimizar(atrib, aulas, e, iter = 4000) {
  const cur = { ...atrib };
  const profs = Object.fromEntries(e.professores.map((p) => [p.matricula, p]));
  const porId = Object.fromEntries(aulas.map((a) => [a.id, a]));
  const noSlot = new Map();
  aulas.forEach((a) => noSlot.set(a.prof + '@' + cur[a.id], a.id));
  const rnd = mulberry32(20260806);
  let base = pontuar(cur, aulas, e);
  const porTurma = {};
  aulas.forEach((a) => { if (!porTurma[a.turma]) porTurma[a.turma] = []; porTurma[a.turma].push(a.id); });
  const turmas = Object.keys(porTurma);
  if (!turmas.length) return cur;

  for (let i = 0; i < iter; i++) {
    const l = porTurma[turmas[Math.floor(rnd() * turmas.length)]];
    const x = l[Math.floor(rnd() * l.length)], y = l[Math.floor(rnd() * l.length)];
    if (x === y || cur[x] === cur[y]) continue;
    const ax = porId[x], ay = porId[y];
    const px = profs[ax.prof], py = profs[ay.prof];
    if (!px || !py || px.disp[cur[y]] === false || py.disp[cur[x]] === false) continue;
    if (ax.prof !== ay.prof) {
      const ocupaX = noSlot.get(ax.prof + '@' + cur[y]);
      const ocupaY = noSlot.get(ay.prof + '@' + cur[x]);
      if ((ocupaX && ocupaX !== y) || (ocupaY && ocupaY !== x)) continue;
    }
    const sx = cur[x], sy = cur[y];
    cur[x] = sy; cur[y] = sx;
    const nova = pontuar(cur, aulas, e);
    if (nova > base) {
      base = nova;
      noSlot.delete(ax.prof + '@' + sx); noSlot.delete(ay.prof + '@' + sy);
      noSlot.set(ax.prof + '@' + sy, x); noSlot.set(ay.prof + '@' + sx, y);
    } else { cur[x] = sx; cur[y] = sy; }
  }
  return cur;
}

export function resolver(e, tentativas = 40) {
  const slots = gerarSlots(e.dias, e.horarios);
  const aulas = montarAulas(e);
  if (!aulas.length) return { ok: false, motivo: 'A grade curricular está vazia.' };

  let melhor = null, melhorPont = -Infinity, ultimaFalha = '';
  for (let r = 0; r < tentativas; r++) {
    const t = tentativa(e, slots, aulas, r);
    if (t.falha) { ultimaFalha = t.falha; continue; }
    const ot = otimizar(t.atrib, aulas, e);
    const p = pontuar(ot, aulas, e);
    if (p > melhorPont) { melhorPont = p; melhor = ot; }
    if (r >= 7 && melhor) break;
  }
  if (!melhor) return { ok: false, motivo: ultimaFalha || 'Nenhuma combinação satisfaz todas as restrições.' };
  return { ok: true, atrib: melhor, pontuacao: Math.round(melhorPont), aulas: aulas.map((a) => ({ ...a })) };
}

export function conferir(res, e) {
  if (!res || !res.ok) return [];
  const f = [], vT = new Set(), vP = new Set();
  res.aulas.forEach((a) => {
    const s = res.atrib[a.id];
    if (vT.has(a.turma + '@' + s)) f.push('Duas aulas na mesma turma no mesmo tempo.');
    if (vP.has(a.prof + '@' + s)) f.push('Professor em duas turmas no mesmo tempo.');
    vT.add(a.turma + '@' + s); vP.add(a.prof + '@' + s);
    const p = e.professores.find((x) => x.matricula === a.prof);
    if (p && p.disp[s] === false) f.push(`${p.nome} alocado fora da disponibilidade.`);
  });
  const slots = gerarSlots(e.dias, e.horarios);
  let vagos = 0;
  e.turmas.forEach((t) => slots.forEach((s) => { if (!vT.has(t.id + '@' + s.id)) vagos++; }));
  if (vagos) f.push(`${vagos} tempo(s) vago(s) — isso não deveria acontecer.`);
  return [...new Set(f)];
}

/* ---------------- utilidades ---------------- */

export function extrairJSON(txt) {
  const l = txt.replace(/```json/gi, '').replace(/```/g, '').trim();
  const i = l.search(/[[{]/), j = Math.max(l.lastIndexOf(']'), l.lastIndexOf('}'));
  if (i < 0 || j < i) throw new Error('O Claude respondeu sem JSON válido. Tente de novo.');
  return JSON.parse(l.slice(i, j + 1));
}

export function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
